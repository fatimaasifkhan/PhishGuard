import pandas as pd

# Load CSV
df = pd.read_csv("dataset.csv")

# Strip spaces from label and convert to numeric
df['label'] = df['label'].astype(str).str.strip()

# Keep only rows where label is exactly '0' or '1'
df = df[df['label'].isin(['0', '1'])]

# Convert label to integer
df['label'] = df['label'].astype(int)

# Reset index
df.reset_index(drop=True, inplace=True)

# Save cleaned dataset
df.to_csv("dataset_clean.csv", index=False)

print("Cleaned dataset saved as dataset_clean.csv")
print("Label counts:")
print(df['label'].value_counts())
