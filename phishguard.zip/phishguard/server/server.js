// server.js
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const { spawn } = require('child_process');

const app = express();
app.use(cors());
app.use(express.json()); // parse JSON bodies

// =============== SUSPICIOUS KEYWORDS (Heuristic System) ===============
const suspiciousKeywords = [
    "login", "update", "verify", "account", "secure",
    "free", "claim", "bank", "paypal", "malicious",
    "phish", "password", "support", "alert"
];

// ============================= ROUTE ================================
app.post('/checkurl', (req, res) => {
    const { url } = req.body;
    if (!url) return res.status(400).json({ error: "No URL provided" });

    // ---- Heuristic Check ----
    const heuristicFlag = suspiciousKeywords.some(word =>
        url.toLowerCase().includes(word)
    );

    // ---- Run Python ML Model ----
    const py = spawn('python', ['ml_check_url.py', url]);

    let mlResult = "";
    let mlErr = "";

    py.stdout.on("data", data => mlResult += data.toString());
    py.stderr.on("data", data => mlErr += data.toString());

    py.on("close", () => {
        mlResult = mlResult.trim();
        const mlFlag = mlResult === "1"; // ML prediction 1 = phishing

        // ---- Final Result: If ML OR heuristic says phishing → phishing ----
        const finalPhishing = mlFlag || heuristicFlag;

        return res.json({
            phishing: finalPhishing,
            ml: mlResult || null,
            heuristic: heuristicFlag,
            vt: false,
            py_error: mlErr || null
        });
    });
});

// ============================ START SERVER ============================
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
