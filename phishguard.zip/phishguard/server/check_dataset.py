import pandas as pd

# Load your dataset
df = pd.read_csv("dataset.csv")

# Show first 5 rows
print("First 5 rows:")
print(df.head())

# Show counts of each label
print("\nLabel counts:")
print(df['label'].value_counts())
