import sys
import joblib

url = sys.argv[1]

# Load model and vectorizer
clf = joblib.load("url_model.pkl")
vectorizer = joblib.load("url_vectorizer.pkl")

# Transform URL
X = vectorizer.transform([url])

# Predict
pred = clf.predict(X)[0]

print(pred)  # 1 = phishing, 0 = safe
