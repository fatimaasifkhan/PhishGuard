import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.ensemble import RandomForestClassifier
import joblib

# Load cleaned dataset
df = pd.read_csv("dataset_clean.csv")

# Features (URLs) and labels
X = df['url']
y = df['label']

# Convert URLs to TF-IDF features
vectorizer = TfidfVectorizer(analyzer='char', ngram_range=(3, 5))
X_vect = vectorizer.fit_transform(X)

# Split data
X_train, X_test, y_train, y_test = train_test_split(X_vect, y, test_size=0.2, random_state=42)

# Train Random Forest
clf = RandomForestClassifier(n_estimators=200, random_state=42)
clf.fit(X_train, y_train)

# Evaluate
score = clf.score(X_test, y_test)
print(f"Test Accuracy: {score*100:.2f}%")

# Save model and vectorizer
joblib.dump(clf, "url_model.pkl")
joblib.dump(vectorizer, "url_vectorizer.pkl")
print("Model and vectorizer saved!")
