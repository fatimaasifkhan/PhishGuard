// Collection of fast string/URL-based checks. Keep this synchronous and fast.


function parseHostname(url) {
try {
const u = new URL(url);
return u.hostname.toLowerCase();
} catch (e) {
return '';
}
}


export function checkHeuristics(url) {
const host = parseHostname(url);
const reasons = [];


// 1. Lookalike unicode / punycode
if (/xn--/.test(host)) reasons.push('punycode');


// 2. Lots of subdomains or dots
const dotCount = (host.match(/\./g) || []).length;
if (dotCount >= 4) reasons.push('many_subdomains');


// 3. IP address instead of domain
if (/^\d+\.\d+\.\d+\.\d+$/.test(host)) reasons.push('ip_as_hostname');


// 4. @ symbol in URL
if (url.includes('@')) reasons.push('contains_at');


// 5. Long URL (excessive length)
if (url.length > 100) reasons.push('long_url');


// 6. Suspicious TLDs (customize list)
const suspiciousTlds = ['zip','review','top','country'];
const tld = host.split('.').pop();
if (suspiciousTlds.includes(tld)) reasons.push('suspicious_tld');


// Add more heuristics as needed
return { suspicious: reasons.length > 0, reasons };
}


// For use in background.js when bundling
if (typeof module !== 'undefined') module.exports = { checkHeuristics };