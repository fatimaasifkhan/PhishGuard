// content_script.js
window.addEventListener('PHISH_RESULT', (e) => {
  const result = e.detail;
  if (result.suspicious) showBanner(result.reasons);
});

function showBanner(reasons) {
  if (document.getElementById("phishguard-banner")) return;
  const banner = document.createElement("div");
  banner.id = "phishguard-banner";
  banner.style = `
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    z-index: 999999;
    background: #ffcccc;
    color: black;
    padding: 10px;
    text-align: center;
    font-family: Arial;
    font-size: 14px;
  `;
  banner.textContent = "⚠️ PhishGuard Warning: This site looks suspicious. Reasons: " + reasons.join(", ");
  document.body.prepend(banner);
}
