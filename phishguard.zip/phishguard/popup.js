document.addEventListener("DOMContentLoaded", async () => {
    const resultDiv = document.getElementById("result");

    try {
        // Get active tab
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        const url = tab.url;

        if (!url) {
            resultDiv.textContent = "Could not get current tab URL.";
            resultDiv.style.color = "red";
            return;
        }

        // Send URL to backend
        const response = await fetch("http://localhost:3000/checkurl", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ url })
        });

        const data = await response.json();

        if (data.phishing) {
            resultDiv.textContent = "⚠️ Warning! This site may be dangerous!";
            resultDiv.style.color = "red";
        } else {
            resultDiv.textContent = "✅ This site is safe!";
            resultDiv.style.color = "green";
        }

    } catch (err) {
        console.error(err);
        resultDiv.textContent = "Error checking URL.";
        resultDiv.style.color = "red";
    }
});
