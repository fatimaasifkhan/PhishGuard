// background.js

// Listen for messages from popup.js
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === "analyze_url") {
    const url = msg.url;
    const result = checkHeuristics(url);
    sendResponse(result);  // VERY IMPORTANT
  }
  return true; // keep message channel open
});

// Heuristics function
function checkHeuristics(url) {
  const reasons = [];

  try {
    const parsed = new URL(url);

    if (url.includes("@")) reasons.push("Contains '@' symbol (phishing pattern)");

    if (/^\d{1,3}(\.\d{1,3}){3}$/.test(parsed.hostname))
      reasons.push("Uses IP as domain");

    if ((parsed.hostname.match(/\./g) || []).length > 3)
      reasons.push("Too many subdomains");

    if (!url.startsWith("https://"))
      reasons.push("Not using HTTPS");

    const badWords = ["login", "verify", "update", "secure", "account", "bank", "paypal"];
    if (badWords.some(word => parsed.hostname.includes(word)))
      reasons.push("Suspicious keyword in domain");

  } catch (err) {
    reasons.push("Invalid URL format");
  }

  return {
    suspicious: reasons.length > 0,
    reasons
  };
}
