import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report
import joblib

# 1. Load phishing URLs from your PhishTank CSV
data = pd.read_csv("dataset.csv")  # replace with your CSV path
phish_urls = data['url'].tolist()

# 2. Define safe URLs
safe_urls = [
    "https://google.com",
    "https://github.com",
    "https://stackoverflow.com",
    "https://wikipedia.org",
    "https://openai.com",
    "https://microsoft.com",
    "https://apple.com"
]

# 3. Combine URLs and labels
urls = phish_urls + safe_urls
labels = [1]*len(phish_urls) + [0]*len(safe_urls)

# 4. Feature extraction
def extract_features(url):
    features = {}
    features['length'] = len(url)
    features['num_digits'] = sum(c.isdigit() for c in url)
    features['num_dots'] = url.count('.')
    features['has_at'] = 1 if '@' in url else 0
    keywords = ['login','secure','account','bank','verify','update']
    features['has_keyword'] = 1 if any(k in url for k in keywords) else 0
    return features

X = pd.DataFrame([extract_features(u) for u in urls])
y = labels

# 5. Split dataset
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 6. Train RandomForest model
clf = RandomForestClassifier(n_estimators=100, random_state=42)
clf.fit(X_train, y_train)

# 7. Save trained model
joblib.dump(clf, 'phish_model.pkl')
print("Model trained and saved as phish_model.pkl")

# 8. Evaluate
y_pred = clf.predict(X_test)
print("\nClassification Report:\n")
print(classification_report(y_test, y_pred))
